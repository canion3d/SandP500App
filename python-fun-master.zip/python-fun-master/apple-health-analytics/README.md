## Analyze Apple Health data

Dependencies: numpy, pandas, matplotlib

## Export health data

On iPhone go to Health App -> Profile -> Export data -> Send to your computer

